import { useEffect, useState } from "react";
import { api, type AdminUser, type GlobalSource, type EventCategory, type Community, type CommunityMember, type CategoryItem } from "../lib/api";
import { useAuth } from "../state/auth";
import { categoryLabel } from "../lib/format";
import { Button, Input, Label } from "../ui/components";

const ALL_CATEGORIES: EventCategory[] = [
  "KONZERT", "FESTIVAL", "MUSICAL", "OPER", "KABARETT", "OPEN_MIC", "DJ_EVENT",
  "THEATER", "COMEDY", "TANZ", "ZAUBERSHOW",
  "AUSSTELLUNG", "LESUNG", "FILM", "FOTOGRAFIE", "MUSEUM",
  "FLOHMARKT", "WOCHENMARKT", "WEIHNACHTSMARKT", "MESSE", "FOOD_FESTIVAL",
  "SPORT", "LAUF", "TURNIER", "YOGA", "WANDERUNG",
  "KINDERTHEATER", "FAMILIENTAG", "KINDER_WORKSHOP",
  "WEINPROBE", "CRAFT_BEER", "KOCHKURS", "FOOD_TRUCK", "KULINARISCHE_TOUR",
  "WORKSHOP", "SEMINAR", "KONFERENZ", "NETWORKING", "VORTRAG",
  "CLUBNACHT", "KARAOKE", "PARTY",
  "KARNEVAL", "OKTOBERFEST", "SILVESTER", "STADTFEST", "STRASSENFEST",
  "SONSTIGES",
];

export function AdminPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<"users" | "events" | "sources" | "communities" | "categories" | "settings">("users");

  // Site settings state
  const [siteSettings, setSiteSettings] = useState<Record<string, string>>({});
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [heroLine1, setHeroLine1] = useState("Entdecke Events");
  const [heroLine2, setHeroLine2] = useState("in deiner N\u00e4he");
  const [heroSubtitle, setHeroSubtitle] = useState("Konzerte, Theater, Lesungen, Comedy und mehr \u2013 finde Veranstaltungen, die dich begeistern.");
  const [heroBadge, setHeroBadge] = useState("Neue Events in deiner N\u00e4he");
  const [heroGradientLine, setHeroGradientLine] = useState<"1" | "2">("2");
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedUser, setExpandedUser] = useState<string | null>(null);
  const [newUrls, setNewUrls] = useState<Record<string, string>>({});
  const [tokenInputs, setTokenInputs] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);

  // User search state
  const [userSearch, setUserSearch] = useState("");
  const [searchResults, setSearchResults] = useState<(AdminUser & { _count: { events: number; communityMembers: number } })[]>([]);
  const [searchTotal, setSearchTotal] = useState(0);
  const [searchPage, setSearchPage] = useState(1);
  const [searchPages, setSearchPages] = useState(1);
  const [searching, setSearching] = useState(false);

  // Global sources state
  const [sources, setSources] = useState<GlobalSource[]>([]);
  const [sourcesLoading, setSourcesLoading] = useState(false);
  const [newSource, setNewSource] = useState({ url: "", label: "", defaultCategory: "", defaultCity: "" });
  const [scrapeResult, setScrapeResult] = useState<Record<string, string>>({});

  // Communities state
  const [communities, setCommunities] = useState<Community[]>([]);
  const [communitiesLoading, setCommunitiesLoading] = useState(false);
  const [expandedCommunity, setExpandedCommunity] = useState<string | null>(null);
  const [communityMembers, setCommunityMembers] = useState<CommunityMember[]>([]);
  const [communityMembersLoading, setCommunityMembersLoading] = useState(false);
  const [newCommunity, setNewCommunity] = useState({
    slug: "", name: "", shortDescription: "", description: "",
    country: "", flagCode: "", language: "", city: "", region: "", timezone: "",
    contactEmail: "", website: "", phone: "",
    instagram: "", facebook: "", twitter: "", linkedin: "", youtube: "", discord: "", telegram: "", tiktok: "",
    category: "", tags: "" as string, visibility: "PUBLIC", rules: "", welcomeMessage: "",
    maxMembers: "" as string, color: "", imageUrl: "", bannerUrl: "",
  });
  const [roleAssign, setRoleAssign] = useState({ userId: "", userName: "", role: "MEMBER" });
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [memberSearch, setMemberSearch] = useState("");

  // Events (view counts) state
  type AdminEvent = { id: string; title: string; category: string; city: string; startsAt: string; isFeatured: boolean; isPromoted: boolean; createdAt: string; organizer: { id: string; name: string } | null; _count: { views: number; ticketClicks: number } };
  const [adminEvents, setAdminEvents] = useState<AdminEvent[]>([]);
  const [adminEventsLoading, setAdminEventsLoading] = useState(false);
  const [eventsSort, setEventsSort] = useState<"views" | "clicks" | "date">("views");
  const [eventsSearch, setEventsSearch] = useState("");

  // Categories state
  const [categoryItems, setCategoryItems] = useState<CategoryItem[]>([]);
  const [categoriesItemsLoading, setCategoriesItemsLoading] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [showCreateCategory, setShowCreateCategory] = useState(false);
  const [newCategory, setNewCategory] = useState({ slug: "", name: "", eventCategory: "", imageUrl: "", iconUrl: "", icon: "", sortOrder: "0" });

  const tabConfig: { id: typeof tab; label: string; emoji: string; count: number | null }[] = [
    { id: "users", label: "Benutzer", emoji: "👥", count: users.length },
    { id: "events", label: "Events", emoji: "📊", count: adminEvents.length || null },
    { id: "communities", label: "Communities", emoji: "🌍", count: communities.length },
    { id: "categories", label: "Kategorien", emoji: "🏷️", count: categoryItems.length },
    { id: "sources", label: "Quellen", emoji: "🔗", count: sources.length },
    { id: "settings", label: "Einstellungen", emoji: "⚙️", count: null },
  ];

  async function loadUsers() {
    try {
      const res = await api.admin.listUsers();
      setUsers(res.users);
    } catch {
      setUsers([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadAdminEvents() {
    setAdminEventsLoading(true);
    try {
      const res = await api.admin.listEvents();
      setAdminEvents(res.events);
    } catch { setAdminEvents([]); }
    finally { setAdminEventsLoading(false); }
  }

  async function loadSources() {
    setSourcesLoading(true);
    try {
      const res = await api.admin.listGlobalSources();
      setSources(res.sources);
    } catch { setSources([]); }
    finally { setSourcesLoading(false); }
  }

  async function loadCommunities() {
    setCommunitiesLoading(true);
    try {
      const res = await api.admin.listCommunities();
      setCommunities(res.communities);
    } catch { setCommunities([]); }
    finally { setCommunitiesLoading(false); }
  }

  async function loadCommunityMembers(communityId: string, q = "") {
    setCommunityMembersLoading(true);
    try {
      const res = await api.admin.listCommunityMembers(communityId, q);
      setCommunityMembers(res.members);
    } catch { setCommunityMembers([]); }
    finally { setCommunityMembersLoading(false); }
  }

  async function searchUsers(q: string, page = 1) {
    setSearching(true);
    try {
      const res = await api.admin.searchUsers(q, page);
      setSearchResults(res.users);
      setSearchTotal(res.total);
      setSearchPage(res.page);
      setSearchPages(res.pages);
    } catch { setSearchResults([]); }
    finally { setSearching(false); }
  }

  async function loadSettings() {
    setSettingsLoading(true);
    try {
      const res = await api.admin.getSettings();
      setSiteSettings(res.settings);
      if (res.settings.heroLine1) setHeroLine1(res.settings.heroLine1);
      if (res.settings.heroLine2) setHeroLine2(res.settings.heroLine2);
      if (res.settings.heroSubtitle) setHeroSubtitle(res.settings.heroSubtitle);
      if (res.settings.heroBadge) setHeroBadge(res.settings.heroBadge);
      if (res.settings.heroGradientLine) setHeroGradientLine(res.settings.heroGradientLine as "1" | "2");
    } catch { /* ignore */ }
    finally { setSettingsLoading(false); }
  }

  async function saveHeroSettings() {
    setSettingsSaving(true);
    try {
      const res = await api.admin.updateSettings({
        heroLine1,
        heroLine2,
        heroSubtitle,
        heroBadge,
        heroGradientLine,
      });
      setSiteSettings(res.settings);
      alert("Einstellungen gespeichert!");
    } catch {
      alert("Fehler beim Speichern.");
    } finally { setSettingsSaving(false); }
  }

  async function loadCategoryItems() {
    setCategoriesItemsLoading(true);
    try {
      const res = await api.admin.listCategories();
      setCategoryItems(res.categories);
    } catch { setCategoryItems([]); }
    finally { setCategoriesItemsLoading(false); }
  }

  useEffect(() => {
    loadUsers();
    loadSettings();
    loadAdminEvents();
  }, []);

  if (!user?.isAdmin) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <div className="text-4xl">­ƒöÆ</div>
        <p className="mt-4 text-surface-400">Kein Zugriff. Nur Administratoren koennen diese Seite sehen.</p>
      </div>
    );
  }

  async function togglePartner(userId: string, current: boolean) {
    setBusy(userId);
    try {
      await api.admin.updateUser(userId, { isPartner: !current });
      await loadUsers();
    } catch {
      alert("Fehler beim Aendern des Partner-Status.");
    } finally {
      setBusy(null);
    }
  }

  async function addUrls(userId: string) {
    const raw = newUrls[userId] || "";
    const lines = raw
      .split("\n")
      .map((l: string) => l.trim())
      .filter((l: string) => l.length > 0);

    if (lines.length === 0) return;

    const urlObjects = lines.map((line: string) => {
      const parts = line.split("|").map((p: string) => p.trim());
      return { url: parts[0], label: parts[1] || undefined };
    });

    // Validate URLs
    const invalid = urlObjects.filter((u: { url: string }) => {
      try {
        new URL(u.url);
        return false;
      } catch {
        return true;
      }
    });

    if (invalid.length > 0) {
      alert(`Ungueltige URLs:\n${invalid.map((u: { url: string }) => u.url).join("\n")}`);
      return;
    }

    setBusy(userId);
    try {
      const result = await api.admin.addUrls(userId, urlObjects);
      setNewUrls((prev) => ({ ...prev, [userId]: "" }));
      await loadUsers();
      alert(`${result.created} URL(s) hinzugefuegt${result.skipped > 0 ? `, ${result.skipped} bereits vorhanden` : ""}.`);
    } catch {
      alert("Fehler beim Hinzufuegen der URLs.");
    } finally {
      setBusy(null);
    }
  }

  async function deleteUrl(urlId: string) {
    if (!confirm("URL wirklich entfernen?")) return;
    try {
      await api.admin.deleteUrl(urlId);
      await loadUsers();
    } catch {
      alert("Fehler beim Entfernen.");
    }
  }

  async function toggleUrlActive(urlId: string, current: boolean) {
    try {
      await api.admin.updateUrl(urlId, { isActive: !current });
      await loadUsers();
    } catch {
      alert("Fehler.");
    }
  }

  async function addSource() {
    if (!newSource.url.trim()) return;
    try { new URL(newSource.url); } catch { return alert("Ungueltige URL."); }
    setBusy("add-source");
    try {
      await api.admin.addGlobalSource({
        url: newSource.url,
        label: newSource.label || undefined,
        defaultCategory: newSource.defaultCategory || undefined,
        defaultCity: newSource.defaultCity || undefined,
      });
      setNewSource({ url: "", label: "", defaultCategory: "", defaultCity: "" });
      await loadSources();
    } catch (e: any) {
      alert(e?.message || "Fehler beim Hinzufuegen.");
    } finally { setBusy(null); }
  }

  async function deleteSource(id: string) {
    if (!confirm("Quelle wirklich entfernen?")) return;
    try { await api.admin.deleteGlobalSource(id); await loadSources(); }
    catch { alert("Fehler."); }
  }

  async function toggleSource(id: string, current: boolean) {
    try { await api.admin.updateGlobalSource(id, { isActive: !current }); await loadSources(); }
    catch { alert("Fehler."); }
  }

  async function scrapeSource(id: string) {
    setBusy(id);
    setScrapeResult((p) => ({ ...p, [id]: "Scraping..." }));
    try {
      const res = await api.admin.scrapeGlobalSource(id);
      setScrapeResult((p) => ({ ...p, [id]: res.error ? `Fehler: ${res.error}` : `${res.newEvents} neue, ${res.skipped} uebersprungen` }));
      await loadSources();
    } catch (e: any) {
      setScrapeResult((p) => ({ ...p, [id]: `Fehler: ${e?.message || "Unbekannt"}` }));
    } finally { setBusy(null); }
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Admin Overview */}
      <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-surface-900 p-6 sm:p-8">
        <div className="pointer-events-none absolute -top-16 right-0 h-56 w-56 rounded-full bg-accent-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 left-10 h-56 w-56 rounded-full bg-blue-500/10 blur-3xl" />

        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-3">
            <span className="inline-flex items-center gap-2 rounded-full border border-red-500/30 bg-red-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-red-400">
              <span className="text-xs">⚙️</span> Admin Control
            </span>
            <div>
              <h1 className="text-3xl font-black tracking-tight text-white sm:text-4xl">Administration</h1>
              <p className="mt-1 text-sm text-surface-400">Zentrale Steuerung fuer Nutzer, Communities, Quellen und Kategorien.</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:justify-end">
            <button
              onClick={() => setTab("users")}
              className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-surface-300 transition hover:border-white/20 hover:text-white"
            >
              Nutzer verwalten
            </button>
            <button
              onClick={() => setTab("communities")}
              className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-surface-300 transition hover:border-white/20 hover:text-white"
            >
              Communities
            </button>
            <button
              onClick={() => setTab("sources")}
              className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-surface-300 transition hover:border-white/20 hover:text-white"
            >
              Quellen
            </button>
            <button
              onClick={() => setTab("settings")}
              className="rounded-xl border border-accent-500/30 bg-accent-500/15 px-3 py-2 text-xs font-semibold text-accent-300 transition hover:bg-accent-500/25"
            >
              Hero Settings
            </button>
          </div>
        </div>

        <div className="relative mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-[11px] uppercase tracking-wider text-surface-500">Benutzer</p>
            <p className="mt-1 text-2xl font-bold text-white">{users.length}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-[11px] uppercase tracking-wider text-surface-500">Communities</p>
            <p className="mt-1 text-2xl font-bold text-white">{communities.length}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-[11px] uppercase tracking-wider text-surface-500">Kategorien</p>
            <p className="mt-1 text-2xl font-bold text-white">{categoryItems.length}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-[11px] uppercase tracking-wider text-surface-500">Globale Quellen</p>
            <p className="mt-1 text-2xl font-bold text-white">{sources.length}</p>
          </div>
        </div>
      </section>

      {/* Tabs */}
      <div className="rounded-2xl border border-white/[0.08] bg-surface-950/70 p-2">
        <div className="flex gap-1 overflow-x-auto">
          {tabConfig.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
                tab === t.id
                  ? "bg-accent-500 text-white shadow-lg shadow-accent-500/20"
                  : "text-surface-400 hover:bg-white/[0.05] hover:text-white"
              }`}
            >
              <span>{t.emoji}</span>
              <span className="hidden sm:inline">{t.label}</span>
              {t.count !== null && (
                <span
                  className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                    tab === t.id ? "bg-white/20 text-white" : "bg-white/[0.06] text-surface-500"
                  }`}
                >
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Events Tab ─── */}
      {tab === "events" && (
        <section className="space-y-4 rounded-3xl border border-white/[0.08] bg-surface-900/70 p-5 sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-base font-semibold text-white">Events & View-Counts</h2>
              <p className="text-xs text-surface-400 mt-0.5">Alle Events sortiert nach Aufrufen. Klicks = Ticket-Link-Klicks.</p>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Event suchen..."
                value={eventsSearch}
                onChange={(e) => setEventsSearch(e.target.value)}
                className="rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-xs text-white placeholder-surface-500 outline-none focus:border-accent-500/40 w-44"
              />
              <select
                value={eventsSort}
                onChange={(e) => setEventsSort(e.target.value as "views" | "clicks" | "date")}
                className="rounded-lg border border-white/[0.08] bg-surface-900 px-2 py-1.5 text-xs text-white outline-none focus:border-accent-500/40"
              >
                <option value="views">Nach Views</option>
                <option value="clicks">Nach Klicks</option>
                <option value="date">Nach Datum</option>
              </select>
              <button onClick={loadAdminEvents} className="rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-xs text-surface-300 hover:text-white transition-colors">
                ↻ Neu laden
              </button>
            </div>
          </div>

          {adminEventsLoading ? (
            <div className="py-12 text-center text-sm text-surface-500">Lade Events...</div>
          ) : (
            <>
              {/* Summary stats */}
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4 text-center">
                  <p className="text-[11px] uppercase tracking-wider text-surface-500">Events gesamt</p>
                  <p className="mt-1 text-2xl font-bold text-white">{adminEvents.length}</p>
                </div>
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4 text-center">
                  <p className="text-[11px] uppercase tracking-wider text-surface-500">Views gesamt</p>
                  <p className="mt-1 text-2xl font-bold text-accent-400">{adminEvents.reduce((s, e) => s + e._count.views, 0).toLocaleString("de-DE")}</p>
                </div>
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4 text-center">
                  <p className="text-[11px] uppercase tracking-wider text-surface-500">Ticket-Klicks</p>
                  <p className="mt-1 text-2xl font-bold text-neon-green">{adminEvents.reduce((s, e) => s + e._count.ticketClicks, 0).toLocaleString("de-DE")}</p>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto rounded-2xl border border-white/[0.06]">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/[0.06] bg-white/[0.02]">
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-surface-500">Event</th>
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-surface-500">Stadt</th>
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-surface-500">Datum</th>
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-surface-500">Veranstalter</th>
                      <th className="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-surface-500">
                        <span className="text-accent-400">Views</span>
                      </th>
                      <th className="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-surface-500">
                        <span className="text-neon-green">Klicks</span>
                      </th>
                      <th className="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-surface-500">Conv.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {adminEvents
                      .filter((e) => !eventsSearch || e.title.toLowerCase().includes(eventsSearch.toLowerCase()) || e.city?.toLowerCase().includes(eventsSearch.toLowerCase()))
                      .sort((a, b) => {
                        if (eventsSort === "views") return b._count.views - a._count.views;
                        if (eventsSort === "clicks") return b._count.ticketClicks - a._count.ticketClicks;
                        return new Date(b.startsAt).getTime() - new Date(a.startsAt).getTime();
                      })
                      .map((e, idx) => {
                        const conv = e._count.views > 0 ? Math.round((e._count.ticketClicks / e._count.views) * 1000) / 10 : 0;
                        return (
                          <tr key={e.id} className={`border-b border-white/[0.04] transition-colors hover:bg-white/[0.03] ${idx % 2 === 0 ? "" : "bg-white/[0.01]"}`}>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                {e.isFeatured && <span className="rounded-full bg-accent-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-accent-300">★</span>}
                                <a href={`/events/${e.id}`} target="_blank" rel="noreferrer" className="max-w-[200px] truncate text-sm font-medium text-white hover:text-accent-300 transition-colors">
                                  {e.title}
                                </a>
                              </div>
                              <div className="mt-0.5 text-[11px] text-surface-500">{categoryLabel(e.category as any)}</div>
                            </td>
                            <td className="px-4 py-3 text-xs text-surface-400">{e.city || "–"}</td>
                            <td className="px-4 py-3 text-xs text-surface-400 whitespace-nowrap">
                              {new Date(e.startsAt).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "2-digit" })}
                            </td>
                            <td className="px-4 py-3 text-xs text-surface-400">{e.organizer?.name || "–"}</td>
                            <td className="px-4 py-3 text-right">
                              <span className="font-semibold text-accent-400">{e._count.views.toLocaleString("de-DE")}</span>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <span className="font-semibold text-neon-green">{e._count.ticketClicks.toLocaleString("de-DE")}</span>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <span className={`text-xs font-medium ${conv >= 5 ? "text-neon-green" : conv >= 1 ? "text-yellow-400" : "text-surface-500"}`}>
                                {conv}%
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
                {adminEvents.filter((e) => !eventsSearch || e.title.toLowerCase().includes(eventsSearch.toLowerCase()) || e.city?.toLowerCase().includes(eventsSearch.toLowerCase())).length === 0 && (
                  <div className="py-10 text-center text-sm text-surface-500">Keine Events gefunden.</div>
                )}
              </div>
            </>
          )}
        </section>
      )}

      {/* ─── Categories Tab ─── */}
      {tab === "categories" && (
        <section className="space-y-4 rounded-3xl border border-white/[0.08] bg-surface-900/70 p-5 sm:p-6">
          <p className="text-sm text-surface-400">
            Kategorien verwalten. Erstellen, Bilder zuweisen und festlegen welche auf der Startseite angezeigt werden.
          </p>

          {/* Create new category toggle */}
          {!showCreateCategory ? (
            <button
              onClick={() => setShowCreateCategory(true)}
              className="w-full rounded-2xl border border-dashed border-accent-500/20 bg-accent-500/5 p-4 text-sm font-medium text-accent-400 hover:bg-accent-500/10 hover:border-accent-500/40 transition-all"
            >
              🏷️ Neue Kategorie erstellen
            </button>
          ) : (
          <div className="rounded-2xl border border-white/[0.08] bg-surface-900 p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div className="text-base font-semibold text-white">🏷️ Neue Kategorie erstellen</div>
              <button onClick={() => setShowCreateCategory(false)} className="text-xs text-surface-500 hover:text-white transition-colors">Abbrechen</button>
            </div>

            {/* Section: Grunddaten */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Grunddaten</div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Name *</Label>
                  <Input value={newCategory.name} onChange={(e: any) => setNewCategory({ ...newCategory, name: e.target.value, slug: e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") })} placeholder="z.B. Konzerte" />
                </div>
                <div>
                  <Label>Slug *</Label>
                  <Input value={newCategory.slug} onChange={(e: any) => setNewCategory({ ...newCategory, slug: e.target.value })} placeholder="z.B. konzerte" />
                  <p className="mt-0.5 text-[10px] text-surface-600">URL-Pfad: /events?category={newCategory.slug || "..."}</p>
                </div>
                <div>
                  <Label>Event-Kategorie (Enum)</Label>
                  <select
                    value={newCategory.eventCategory}
                    onChange={(e: any) => setNewCategory({ ...newCategory, eventCategory: e.target.value })}
                    className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white focus:border-accent-500 focus:outline-none"
                  >
                    <option value="">-- Keine --</option>
                    {ALL_CATEGORIES.map((c) => (
                      <option key={c} value={c}>{categoryLabel(c)}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Icon (Emoji)</Label>
                  <Input value={newCategory.icon} onChange={(e: any) => setNewCategory({ ...newCategory, icon: e.target.value })} placeholder="z.B. ­ƒÄÁ" />
                </div>
                <div>
                  <Label>Sortierung</Label>
                  <Input type="number" value={newCategory.sortOrder} onChange={(e: any) => setNewCategory({ ...newCategory, sortOrder: e.target.value })} placeholder="0" />
                </div>
              </div>
            </div>

            {/* Section: Bilder */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Bilder</div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Bild-URL (Hintergrund)</Label>
                  <Input value={newCategory.imageUrl} onChange={(e: any) => setNewCategory({ ...newCategory, imageUrl: e.target.value })} placeholder="https://images.unsplash.com/..." />
                  {newCategory.imageUrl && (
                    <img src={newCategory.imageUrl} alt="" className="mt-2 h-20 w-full rounded-lg object-cover ring-1 ring-white/10" />
                  )}
                </div>
                <div>
                  <Label>Icon-URL (ueberschreibt Emoji)</Label>
                  <Input value={newCategory.iconUrl} onChange={(e: any) => setNewCategory({ ...newCategory, iconUrl: e.target.value })} placeholder="https://..." />
                  {newCategory.iconUrl && (
                    <img src={newCategory.iconUrl} alt="" className="mt-2 h-10 w-10 rounded-full object-cover ring-1 ring-white/10" />
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2 border-t border-white/[0.06]">
              <Button
                onClick={async () => {
                  if (!newCategory.slug.trim() || !newCategory.name.trim()) return alert("Name und Slug sind Pflicht.");
                  try {
                    await api.admin.createCategory({
                      slug: newCategory.slug.trim(),
                      name: newCategory.name.trim(),
                      eventCategory: newCategory.eventCategory || null,
                      imageUrl: newCategory.imageUrl || null,
                      iconUrl: newCategory.iconUrl || null,
                      icon: newCategory.icon || null,
                      sortOrder: parseInt(newCategory.sortOrder) || 0,
                      showOnHomepage: true,
                    });
                    setNewCategory({ slug: "", name: "", eventCategory: "", imageUrl: "", iconUrl: "", icon: "", sortOrder: "0" });
                    setShowCreateCategory(false);
                    await loadCategoryItems();
                  } catch { alert("Fehler beim Erstellen."); }
                }}
              >
                Kategorie erstellen
              </Button>
              <span className="text-xs text-surface-500">* Pflichtfelder: Name und Slug</span>
            </div>
          </div>
          )}

          {/* Categories list */}
          {categoriesItemsLoading ? (
            <div className="py-8 text-center text-sm text-surface-500">Lade Kategorien...</div>
          ) : categoryItems.length === 0 ? (
            <div className="py-8 text-center text-sm text-surface-500">Noch keine Kategorien vorhanden.</div>
          ) : (
            <div className="space-y-2">
              {categoryItems.map((cat: CategoryItem) => {
                const isExp = expandedCategory === cat.id;
                return (
                  <div key={cat.id} className={`rounded-2xl border overflow-hidden transition-all ${
                    cat.isActive ? "border-white/[0.08] bg-surface-900 hover:border-white/[0.12]" : "border-white/[0.04] bg-surface-900/50 opacity-60"
                  }`}>
                    <button
                      onClick={() => setExpandedCategory(isExp ? null : cat.id)}
                      className="w-full text-left px-5 py-4 hover:bg-white/[0.02] transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {cat.imageUrl ? (
                            <img src={cat.imageUrl} alt="" className="h-12 w-12 rounded-xl object-cover ring-1 ring-white/10" />
                          ) : cat.icon ? (
                            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.05] text-xl">{cat.icon}</span>
                          ) : (
                            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.05] text-surface-500 text-xs">?</span>
                          )}
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-white">{cat.name}</span>
                              <span className="text-xs text-surface-500">/{cat.slug}</span>
                              {cat.eventCategory && (
                                <span className="rounded bg-accent-500/20 px-1.5 py-0.5 text-[10px] text-accent-400">{categoryLabel(cat.eventCategory as any)}</span>
                              )}
                            </div>
                            <div className="mt-0.5 text-xs text-surface-500">Sortierung: {cat.sortOrder}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-xs shrink-0">
                          <span className={`hidden sm:inline ${cat.showOnHomepage ? "text-accent-400" : "text-surface-600"}`}>
                            {cat.showOnHomepage ? "Startseite" : "Versteckt"}
                          </span>
                          <span className={cat.isActive ? "text-emerald-400" : "text-red-400"}>
                            {cat.isActive ? "Aktiv" : "Inaktiv"}
                          </span>
                          <span className="text-surface-600">{isExp ? "▲" : "▼"}</span>
                        </div>
                      </div>
                    </button>

                    {isExp && (
                      <div className="border-t border-white/[0.06] bg-surface-950/40 px-5 py-4 space-y-4">
                        {/* Toggle active & showOnHomepage */}
                        <div className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
                          <div className="text-sm font-medium text-white">Status</div>
                          <div className="flex gap-2">
                            <button
                              onClick={async () => {
                                try {
                                  await api.admin.updateCategory(cat.id, { isActive: !cat.isActive });
                                  await loadCategoryItems();
                                } catch { alert("Fehler."); }
                              }}
                              className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
                                cat.isActive ? "bg-neon-green/20 text-neon-green" : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              {cat.isActive ? "Aktiv" : "Deaktiviert"}
                            </button>
                            <button
                              onClick={async () => {
                                if (!confirm(`Kategorie "${cat.name}" wirklich loeschen?`)) return;
                                try { await api.admin.deleteCategory(cat.id); await loadCategoryItems(); }
                                catch { alert("Fehler."); }
                              }}
                              className="rounded-lg bg-red-500/10 px-3 py-1.5 text-xs text-red-400 hover:bg-red-500/20"
                            >
                              Loeschen
                            </button>
                          </div>
                        </div>

                        {/* Toggle showOnHomepage */}
                        <div className="flex items-center justify-between">
                          <div className="text-sm font-medium text-white">Startseite</div>
                          <button
                            onClick={async () => {
                              try {
                                await api.admin.updateCategory(cat.id, { showOnHomepage: !cat.showOnHomepage });
                                await loadCategoryItems();
                              } catch { alert("Fehler."); }
                            }}
                            className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
                              cat.showOnHomepage
                                ? "bg-accent-500/20 text-accent-400"
                                : "bg-surface-700/50 text-surface-400"
                            }`}
                          >
                            {cat.showOnHomepage ? "Auf Startseite angezeigt" : "Nicht auf Startseite"}
                          </button>
                        </div>

                        {/* Bilder bearbeiten */}
                        <div className="space-y-3">
                          <div className="text-sm font-medium text-white">Bilder</div>
                          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                            <div>
                              <Label>Bild-URL (Hintergrund)</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  defaultValue={cat.imageUrl || ""}
                                  placeholder="https://images.unsplash.com/..."
                                  onBlur={async (e: any) => {
                                    const v = e.target.value.trim() || null;
                                    if (v !== (cat.imageUrl || null)) {
                                      try { await api.admin.updateCategory(cat.id, { imageUrl: v }); await loadCategoryItems(); } catch { alert("Fehler."); }
                                    }
                                  }}
                                />
                                {cat.imageUrl && (
                                  <img src={cat.imageUrl} alt="" className="h-10 w-16 shrink-0 rounded-lg object-cover ring-1 ring-white/10" />
                                )}
                              </div>
                            </div>
                            <div>
                              <Label>Icon-URL (ueberschreibt Emoji)</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  defaultValue={cat.iconUrl || ""}
                                  placeholder="https://..."
                                  onBlur={async (e: any) => {
                                    const v = e.target.value.trim() || null;
                                    if (v !== (cat.iconUrl || null)) {
                                      try { await api.admin.updateCategory(cat.id, { iconUrl: v }); await loadCategoryItems(); } catch { alert("Fehler."); }
                                    }
                                  }}
                                />
                                {cat.iconUrl && (
                                  <img src={cat.iconUrl} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover ring-1 ring-white/10" />
                                )}
                              </div>
                            </div>
                          </div>
                          {cat.imageUrl && (
                            <div>
                              <p className="text-[10px] text-surface-600 mb-1">Vorschau Hintergrundbild:</p>
                              <img src={cat.imageUrl} alt="" className="h-32 w-full rounded-xl object-cover ring-1 ring-white/10" />
                            </div>
                          )}
                          <p className="text-[10px] text-surface-600">Aenderungen werden beim Verlassen des Feldes gespeichert.</p>
                        </div>

                        {/* Grunddaten bearbeiten */}
                        <div className="space-y-3">
                          <div className="text-sm font-medium text-white">Grunddaten</div>
                          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                            <div>
                              <Label>Name</Label>
                              <Input
                                defaultValue={cat.name}
                                onBlur={async (e: any) => {
                                  const v = e.target.value.trim();
                                  if (v && v !== cat.name) {
                                    try { await api.admin.updateCategory(cat.id, { name: v }); await loadCategoryItems(); } catch { alert("Fehler."); }
                                  }
                                }}
                              />
                            </div>
                            <div>
                              <Label>Event-Kategorie (Enum)</Label>
                              <select
                                defaultValue={cat.eventCategory || ""}
                                onChange={async (e: any) => {
                                  const v = e.target.value || null;
                                  try { await api.admin.updateCategory(cat.id, { eventCategory: v }); await loadCategoryItems(); } catch { alert("Fehler."); }
                                }}
                                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white focus:border-accent-500 focus:outline-none"
                              >
                                <option value="">-- Keine --</option>
                                {ALL_CATEGORIES.map((c) => (
                                  <option key={c} value={c}>{categoryLabel(c)}</option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <Label>Icon (Emoji)</Label>
                              <Input
                                defaultValue={cat.icon || ""}
                                onBlur={async (e: any) => {
                                  const v = e.target.value.trim() || null;
                                  if (v !== (cat.icon || null)) {
                                    try { await api.admin.updateCategory(cat.id, { icon: v }); await loadCategoryItems(); } catch { alert("Fehler."); }
                                  }
                                }}
                              />
                            </div>
                            <div>
                              <Label>Sortierung</Label>
                              <Input
                                type="number"
                                defaultValue={cat.sortOrder}
                                onBlur={async (e: any) => {
                                  const v = parseInt(e.target.value) || 0;
                                  if (v !== cat.sortOrder) {
                                    try { await api.admin.updateCategory(cat.id, { sortOrder: v }); await loadCategoryItems(); } catch { alert("Fehler."); }
                                  }
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* ÔöÇÔöÇÔöÇ Settings Tab ÔöÇÔöÇÔöÇ */}
      {tab === "settings" && (
        <section className="space-y-6 rounded-3xl border border-white/[0.08] bg-surface-900/70 p-5 sm:p-6">
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] p-6">
            <h2 className="text-lg font-bold text-white mb-1">Hero-Bereich</h2>
            <p className="text-xs text-surface-500 mb-6">Text und Darstellung des Hero-Bereichs auf der Startseite anpassen.</p>

            {settingsLoading ? (
              <p className="text-sm text-surface-400">Lade Einstellungen...</p>
            ) : (
              <div className="space-y-5">
                {/* Badge text */}
                <div>
                  <Label>Badge-Text (oben)</Label>
                  <Input value={heroBadge} onChange={(e: any) => setHeroBadge(e.target.value)} placeholder="z.B. Neue Events in deiner N\u00e4he" />
                </div>

                {/* Headline Line 1 */}
                <div>
                  <Label>Headline Zeile 1</Label>
                  <Input value={heroLine1} onChange={(e: any) => setHeroLine1(e.target.value)} placeholder="z.B. Entdecke Events" />
                </div>

                {/* Headline Line 2 */}
                <div>
                  <Label>Headline Zeile 2</Label>
                  <Input value={heroLine2} onChange={(e: any) => setHeroLine2(e.target.value)} placeholder="z.B. in deiner N\u00e4he" />
                </div>

                {/* Gradient line selection */}
                <div>
                  <Label>Welche Zeile hat den Gradient-Effekt?</Label>
                  <div className="mt-2 flex gap-3">
                    <button
                      type="button"
                      onClick={() => setHeroGradientLine("1")}
                      className={`flex-1 rounded-xl border px-4 py-3 text-sm font-medium transition-all ${
                        heroGradientLine === "1"
                          ? "border-accent-500/50 bg-accent-500/10 text-white"
                          : "border-white/10 bg-white/[0.03] text-surface-400 hover:border-white/20 hover:text-white"
                      }`}
                    >
                      <span className={heroGradientLine === "1" ? "bg-gradient-to-r from-accent-300 via-purple-400 to-accent-400 bg-clip-text text-transparent" : ""}>
                        {heroLine1 || "Zeile 1"}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setHeroGradientLine("2")}
                      className={`flex-1 rounded-xl border px-4 py-3 text-sm font-medium transition-all ${
                        heroGradientLine === "2"
                          ? "border-accent-500/50 bg-accent-500/10 text-white"
                          : "border-white/10 bg-white/[0.03] text-surface-400 hover:border-white/20 hover:text-white"
                      }`}
                    >
                      <span className={heroGradientLine === "2" ? "bg-gradient-to-r from-accent-300 via-purple-400 to-accent-400 bg-clip-text text-transparent" : ""}>
                        {heroLine2 || "Zeile 2"}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Subtitle */}
                <div>
                  <Label>Untertitel</Label>
                  <textarea
                    value={heroSubtitle}
                    onChange={(e: any) => setHeroSubtitle(e.target.value)}
                    rows={2}
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-surface-500 outline-none transition-colors focus:border-accent-500/50 focus:bg-white/[0.08] focus:ring-1 focus:ring-accent-500/30"
                    placeholder="Beschreibungstext unter der Headline"
                  />
                </div>

                {/* Preview */}
                <div className="rounded-xl border border-white/[0.06] bg-surface-950 p-6 text-center">
                  <p className="text-[10px] uppercase tracking-widest text-surface-500 mb-3">Vorschau</p>
                  <h2 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
                    <span className={heroGradientLine === "1" ? "bg-gradient-to-r from-accent-300 via-purple-400 to-accent-400 bg-clip-text text-transparent" : "text-white"}>
                      {heroLine1}
                    </span>
                    <br />
                    <span className={heroGradientLine === "2" ? "bg-gradient-to-r from-accent-300 via-purple-400 to-accent-400 bg-clip-text text-transparent" : "text-white"}>
                      {heroLine2}
                    </span>
                  </h2>
                  <p className="mt-3 text-sm text-surface-400">{heroSubtitle}</p>
                </div>

                {/* Save */}
                <div className="flex justify-end">
                  <Button onClick={saveHeroSettings} disabled={settingsSaving}>
                    {settingsSaving ? "Speichere..." : "Einstellungen speichern"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* ─── Sources Tab ─── */}
      {tab === "sources" && (
        <section className="space-y-4 rounded-3xl border border-white/[0.08] bg-surface-900/70 p-5 sm:p-6">
          <p className="text-sm text-surface-400">
            Globale Quellen werden automatisch täglich gescrapt. Events landen als Vorschläge im Dashboard.
          </p>

          {/* Add new source */}
          <div className="rounded-2xl border border-white/[0.08] bg-surface-900 p-5 space-y-4">
            <div className="flex items-center gap-2">
              <span>🔗</span>
              <div className="text-sm font-semibold text-white">Neue Quelle hinzufügen</div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label>URL *</Label>
                <Input
                  value={newSource.url}
                  onChange={(e: any) => setNewSource((p) => ({ ...p, url: e.target.value }))}
                  placeholder="https://stadt.de/veranstaltungen"
                />
              </div>
              <div>
                <Label>Bezeichnung</Label>
                <Input
                  value={newSource.label}
                  onChange={(e: any) => setNewSource((p) => ({ ...p, label: e.target.value }))}
                  placeholder="Stadtportal Musterstadt"
                />
              </div>
              <div>
                <Label>Standard-Kategorie</Label>
                <select
                  value={newSource.defaultCategory}
                  onChange={(e: any) => setNewSource((p) => ({ ...p, defaultCategory: e.target.value }))}
                  className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white focus:border-accent-500 focus:outline-none"
                >
                  <option value="">Auto-Erkennung</option>
                  {ALL_CATEGORIES.map((c) => <option key={c} value={c}>{categoryLabel(c)}</option>)}
                </select>
              </div>
              <div>
                <Label>Standard-Stadt</Label>
                <Input
                  value={newSource.defaultCity}
                  onChange={(e: any) => setNewSource((p) => ({ ...p, defaultCity: e.target.value }))}
                  placeholder="z.B. Stuttgart"
                />
              </div>
            </div>
            <Button onClick={addSource} disabled={busy === "add-source" || !newSource.url.trim()}>
              {busy === "add-source" ? "Speichere..." : "Quelle hinzufuegen"}
            </Button>
          </div>

          {/* Sources list */}
          {sourcesLoading ? (
            <div className="py-8 text-center text-sm text-surface-500">Lade Quellen...</div>
          ) : sources.length === 0 ? (
            <div className="py-8 text-center text-sm text-surface-500">Noch keine globalen Quellen hinterlegt.</div>
          ) : (
            <div className="space-y-2">
              {sources.map((s) => (
                <div key={s.id} className={`rounded-2xl border p-4 transition-all ${
                  s.isActive ? "border-white/[0.08] bg-surface-900 hover:border-white/[0.12]" : "border-white/[0.04] bg-surface-900/50 opacity-60"
                }`}>
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className={`h-2 w-2 rounded-full shrink-0 ${s.isActive ? (s.errorCount > 0 ? "bg-amber-400" : "bg-neon-green") : "bg-surface-600"}`} />
                        <span className="font-medium text-white text-sm">{s.label || new URL(s.url).hostname}</span>
                        {s.defaultCategory && (
                          <span className="rounded-full bg-accent-500/20 px-2 py-0.5 text-[9px] font-bold uppercase text-accent-400">
                            {categoryLabel(s.defaultCategory as EventCategory)}
                          </span>
                        )}
                        {s.defaultCity && (
                          <span className="rounded-full bg-blue-500/20 px-2 py-0.5 text-[9px] font-bold uppercase text-blue-400">
                            {s.defaultCity}
                          </span>
                        )}
                      </div>
                      <div className="mt-1 text-xs text-surface-500 truncate">{s.url}</div>
                      <div className="mt-1 flex gap-3 text-[11px] text-surface-600">
                        {s.lastScrapedAt && (
                          <span>Letzter Scan: {new Date(s.lastScrapedAt).toLocaleDateString("de-DE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                        )}
                        {s.lastEventCount > 0 && <span className="text-neon-green">{s.lastEventCount} neue</span>}
                        {s.errorCount > 0 && <span className="text-amber-400">Fehler: {s.lastError}</span>}
                      </div>
                      {scrapeResult[s.id] && (
                        <div className={`mt-1 text-xs ${scrapeResult[s.id].startsWith("Fehler") ? "text-red-400" : "text-neon-green"}`}>
                          {scrapeResult[s.id]}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <button
                        onClick={() => scrapeSource(s.id)}
                        disabled={busy === s.id}
                        className="rounded-lg bg-accent-500/20 px-3 py-1.5 text-xs font-medium text-accent-400 hover:bg-accent-500/30 disabled:opacity-30"
                      >
                        {busy === s.id ? "..." : "Jetzt scannen"}
                      </button>
                      <button
                        onClick={() => toggleSource(s.id, s.isActive)}
                        className="rounded-lg bg-white/5 px-3 py-1.5 text-xs text-surface-400 hover:bg-white/10"
                      >
                        {s.isActive ? "Pause" : "Aktiv"}
                      </button>
                      <button
                        onClick={() => deleteSource(s.id)}
                        className="rounded-lg bg-red-500/10 px-3 py-1.5 text-xs text-red-400 hover:bg-red-500/20"
                      >
                        Entfernen
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* ─── Communities Tab ─── */}
      {tab === "communities" && (
        <section className="space-y-4 rounded-3xl border border-white/[0.08] bg-surface-900/70 p-5 sm:p-6">
          <p className="text-sm text-surface-400">
            Communities verwalten. Neue Communities erstellen, Mitglieder verwalten und Rollen zuweisen.
          </p>

          {/* Create new community toggle */}
          {!showCreateForm ? (
            <button
              onClick={() => setShowCreateForm(true)}
              className="w-full rounded-2xl border border-dashed border-accent-500/20 bg-accent-500/5 p-4 text-sm font-medium text-accent-400 hover:bg-accent-500/10 hover:border-accent-500/40 transition-all"
            >
              🌍 Neue Community erstellen
            </button>
          ) : (
          <div className="rounded-2xl border border-white/[0.08] bg-surface-900 p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div className="text-base font-semibold text-white">🌍 Neue Community erstellen</div>
              <button onClick={() => setShowCreateForm(false)} className="text-xs text-surface-500 hover:text-white transition-colors">Abbrechen</button>
            </div>

            {/* Section: Grunddaten */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Grunddaten</div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Slug *</Label>
                  <Input value={newCommunity.slug} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, slug: e.target.value }))} placeholder="meine-community" />
                  <p className="mt-0.5 text-[10px] text-surface-600">URL-Pfad: /community/{newCommunity.slug || "..."}</p>
                </div>
                <div>
                  <Label>Name *</Label>
                  <Input value={newCommunity.name} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, name: e.target.value }))} placeholder="Meine Community" />
                </div>
                <div>
                  <Label>Kurzbeschreibung</Label>
                  <Input value={newCommunity.shortDescription} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, shortDescription: e.target.value }))} placeholder="Ein Satz ueber die Community (max 300 Zeichen)" />
                </div>
                <div>
                  <Label>Kategorie</Label>
                  <select value={newCommunity.category} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, category: e.target.value }))} className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white focus:border-accent-500 focus:outline-none">
                    <option value="">Keine Kategorie</option>
                    <option value="MUSIK">Musik</option>
                    <option value="KUNST">Kunst & Kultur</option>
                    <option value="SPORT">Sport & Fitness</option>
                    <option value="TECH">Technologie</option>
                    <option value="FOOD">Food & Drinks</option>
                    <option value="BILDUNG">Bildung & Workshops</option>
                    <option value="BUSINESS">Business & Networking</option>
                    <option value="SOCIAL">Soziales & Ehrenamt</option>
                    <option value="NACHTLEBEN">Nachtleben & Party</option>
                    <option value="OUTDOOR">Outdoor & Natur</option>
                    <option value="FAMILIE">Familie & Kinder</option>
                    <option value="SONSTIGES">Sonstiges</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <Label>Beschreibung</Label>
                  <textarea value={newCommunity.description} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, description: e.target.value }))} placeholder="Ausfuehrliche Beschreibung der Community, Ziele, Aktivitaeten..." rows={4} className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white placeholder:text-surface-600 focus:border-accent-500 focus:outline-none resize-none" />
                </div>
                <div>
                  <Label>Tags (kommagetrennt)</Label>
                  <Input value={newCommunity.tags} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, tags: e.target.value }))} placeholder="z.B. musik, konzerte, jazz" />
                </div>
                <div>
                  <Label>Akzentfarbe</Label>
                  <div className="flex gap-2 items-center">
                    <input type="color" value={newCommunity.color || "#6366f1"} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, color: e.target.value }))} className="h-9 w-12 rounded border border-white/10 bg-transparent cursor-pointer" />
                    <Input value={newCommunity.color} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, color: e.target.value }))} placeholder="#6366f1" />
                  </div>
                </div>
              </div>
            </div>

            {/* Section: Bilder */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Bilder</div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Logo-URL</Label>
                  <Input value={newCommunity.imageUrl} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, imageUrl: e.target.value }))} placeholder="https://example.com/logo.png" />
                </div>
                <div>
                  <Label>Banner-URL</Label>
                  <Input value={newCommunity.bannerUrl} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, bannerUrl: e.target.value }))} placeholder="https://example.com/banner.jpg" />
                </div>
              </div>
            </div>

            {/* Section: Standort & Sprache */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Standort & Sprache</div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label>Stadt</Label>
                  <Input value={newCommunity.city} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, city: e.target.value }))} placeholder="z.B. Stuttgart" />
                </div>
                <div>
                  <Label>Region</Label>
                  <Input value={newCommunity.region} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, region: e.target.value }))} placeholder="z.B. Baden-Wuerttemberg" />
                </div>
                <div>
                  <Label>Land (ISO)</Label>
                  <Input value={newCommunity.country} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, country: e.target.value }))} placeholder="DE" />
                </div>
                <div>
                  <Label>Flaggen-Code (ISO)</Label>
                  <div className="flex items-center gap-2">
                    <Input value={newCommunity.flagCode} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, flagCode: e.target.value }))} placeholder="z.B. tr, gr, rs" />
                    {newCommunity.flagCode && (
                      <img src={`https://hatscripts.github.io/circle-flags/flags/${newCommunity.flagCode.toLowerCase()}.svg`} alt="" className="h-8 w-8 rounded-full ring-1 ring-white/10" />
                    )}
                  </div>
                  <p className="mt-0.5 text-[10px] text-surface-600">2-stelliger ISO-Code fuer die Flagge (falls abweichend vom Land)</p>
                </div>
                <div>
                  <Label>Sprache</Label>
                  <Input value={newCommunity.language} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, language: e.target.value }))} placeholder="de" />
                </div>
                <div>
                  <Label>Zeitzone</Label>
                  <Input value={newCommunity.timezone} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, timezone: e.target.value }))} placeholder="Europe/Berlin" />
                </div>
              </div>
            </div>

            {/* Section: Kontakt */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Kontakt</div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label>E-Mail</Label>
                  <Input value={newCommunity.contactEmail} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, contactEmail: e.target.value }))} placeholder="kontakt@community.de" />
                </div>
                <div>
                  <Label>Website</Label>
                  <Input value={newCommunity.website} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, website: e.target.value }))} placeholder="https://community.de" />
                </div>
                <div>
                  <Label>Telefon</Label>
                  <Input value={newCommunity.phone} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, phone: e.target.value }))} placeholder="+49 711 1234567" />
                </div>
              </div>
            </div>

            {/* Section: Social Media */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Social Media</div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div><Label>Instagram</Label><Input value={newCommunity.instagram} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, instagram: e.target.value }))} placeholder="@username oder URL" /></div>
                <div><Label>Facebook</Label><Input value={newCommunity.facebook} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, facebook: e.target.value }))} placeholder="Seiten-URL" /></div>
                <div><Label>Twitter / X</Label><Input value={newCommunity.twitter} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, twitter: e.target.value }))} placeholder="@handle oder URL" /></div>
                <div><Label>LinkedIn</Label><Input value={newCommunity.linkedin} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, linkedin: e.target.value }))} placeholder="Profil-URL" /></div>
                <div><Label>YouTube</Label><Input value={newCommunity.youtube} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, youtube: e.target.value }))} placeholder="Kanal-URL" /></div>
                <div><Label>Discord</Label><Input value={newCommunity.discord} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, discord: e.target.value }))} placeholder="Einladungslink" /></div>
                <div><Label>Telegram</Label><Input value={newCommunity.telegram} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, telegram: e.target.value }))} placeholder="Gruppen-Link" /></div>
                <div><Label>TikTok</Label><Input value={newCommunity.tiktok} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, tiktok: e.target.value }))} placeholder="@username oder URL" /></div>
              </div>
            </div>

            {/* Section: Einstellungen */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-accent-400">Einstellungen</div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Sichtbarkeit</Label>
                  <select value={newCommunity.visibility} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, visibility: e.target.value }))} className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white focus:border-accent-500 focus:outline-none">
                    <option value="PUBLIC">Oeffentlich ÔÇô Jeder kann beitreten</option>
                    <option value="PRIVATE">Privat ÔÇô Nur mit Einladung</option>
                    <option value="HIDDEN">Versteckt ÔÇô Nicht in Suche sichtbar</option>
                  </select>
                </div>
                <div>
                  <Label>Max. Mitglieder (leer = unbegrenzt)</Label>
                  <Input type="number" value={newCommunity.maxMembers} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, maxMembers: e.target.value }))} placeholder="z.B. 500" />
                </div>
                <div className="sm:col-span-2">
                  <Label>Community-Regeln</Label>
                  <textarea value={newCommunity.rules} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, rules: e.target.value }))} placeholder="1. Respektvoller Umgang&#10;2. Kein Spam&#10;3. ..." rows={4} className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white placeholder:text-surface-600 focus:border-accent-500 focus:outline-none resize-none" />
                </div>
                <div className="sm:col-span-2">
                  <Label>Willkommensnachricht</Label>
                  <textarea value={newCommunity.welcomeMessage} onChange={(e: any) => setNewCommunity((p: any) => ({ ...p, welcomeMessage: e.target.value }))} placeholder="Willkommen in unserer Community! Hier findest du..." rows={3} className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white placeholder:text-surface-600 focus:border-accent-500 focus:outline-none resize-none" />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2 border-t border-white/[0.06]">
              <Button
                onClick={async () => {
                  if (!newCommunity.slug.trim() || !newCommunity.name.trim()) return;
                  setBusy("add-community");
                  try {
                    const payload: any = {
                      slug: newCommunity.slug.trim(),
                      name: newCommunity.name.trim(),
                    };
                    const optStr = ["shortDescription","description","imageUrl","bannerUrl","country","flagCode","language","city","region","timezone","contactEmail","website","phone","instagram","facebook","twitter","linkedin","youtube","discord","telegram","tiktok","category","rules","welcomeMessage","color"] as const;
                    for (const k of optStr) { if (newCommunity[k]?.trim()) payload[k] = newCommunity[k].trim(); }
                    if (newCommunity.visibility !== "PUBLIC") payload.visibility = newCommunity.visibility;
                    if (newCommunity.tags.trim()) payload.tags = newCommunity.tags.split(",").map((t: string) => t.trim()).filter(Boolean);
                    if (newCommunity.maxMembers && parseInt(newCommunity.maxMembers) > 0) payload.maxMembers = parseInt(newCommunity.maxMembers);
                    await api.admin.createCommunity(payload);
                    setNewCommunity({
                      slug: "", name: "", shortDescription: "", description: "",
                      country: "", flagCode: "", language: "", city: "", region: "", timezone: "",
                      contactEmail: "", website: "", phone: "",
                      instagram: "", facebook: "", twitter: "", linkedin: "", youtube: "", discord: "", telegram: "", tiktok: "",
                      category: "", tags: "", visibility: "PUBLIC", rules: "", welcomeMessage: "",
                      maxMembers: "", color: "", imageUrl: "", bannerUrl: "",
                    });
                    await loadCommunities();
                  } catch (e: any) { alert(e?.message || "Fehler beim Erstellen."); }
                  finally { setBusy(null); }
                }}
                disabled={busy === "add-community" || !newCommunity.slug.trim() || !newCommunity.name.trim()}
              >
                {busy === "add-community" ? "Erstelle..." : "Community erstellen"}
              </Button>
              <span className="text-xs text-surface-500">* Pflichtfelder: Slug und Name</span>
            </div>
          </div>
          )}

          {/* Communities list */}
          {communitiesLoading ? (
            <div className="py-8 text-center text-sm text-surface-500">Lade Communities...</div>
          ) : communities.length === 0 ? (
            <div className="py-8 text-center text-sm text-surface-500">Noch keine Communities vorhanden.</div>
          ) : (
            <div className="space-y-2">
              {communities.map((c) => {
                const isExp = expandedCommunity === c.id;
                return (
                  <div key={c.id} className={`rounded-2xl border overflow-hidden transition-all ${
                    c.isActive !== false ? "border-white/[0.08] bg-surface-900 hover:border-white/[0.12]" : "border-white/[0.04] bg-surface-900/50 opacity-60"
                  }`}>
                    <button
                      onClick={() => {
                        if (isExp) { setExpandedCommunity(null); }
                        else { setExpandedCommunity(c.id); loadCommunityMembers(c.id); }
                      }}
                      className="w-full text-left px-5 py-4 hover:bg-white/[0.02] transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent-500/10 text-sm font-bold text-accent-400">
                            {c.name?.charAt(0).toUpperCase()}
                          </div>
                          <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white">{c.name}</span>
                            <span className="text-xs text-surface-500">/{c.slug}</span>
                            {c.country && (
                              <img src={`https://hatscripts.github.io/circle-flags/flags/${c.country.toLowerCase()}.svg`} alt="" className="h-4 w-4" />
                            )}
                          </div>
                          {c.description && <div className="mt-0.5 text-xs text-surface-500 line-clamp-1">{c.description}</div>}
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-surface-500 shrink-0">
                          <span className="hidden sm:inline"><span className="text-surface-600">Mitglieder</span> <span className="font-medium text-surface-300">{c._count?.members ?? 0}</span></span>
                          <span className="hidden sm:inline"><span className="text-surface-600">Events</span> <span className="font-medium text-surface-300">{c._count?.events ?? 0}</span></span>
                          <span className="text-surface-600">{isExp ? "▲" : "▼"}</span>
                        </div>
                      </div>
                    </button>

                    {isExp && (
                      <div className="border-t border-white/[0.06] bg-surface-950/40 px-5 py-4 space-y-4">
                        {/* Toggle active */}
                        <div className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
                          <div className="text-sm font-medium text-white">Status</div>
                          <div className="flex gap-2">
                            <button
                              onClick={async () => {
                                try {
                                  await api.admin.updateCommunity(c.id, { isActive: c.isActive === false });
                                  await loadCommunities();
                                } catch { alert("Fehler."); }
                              }}
                              className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
                                c.isActive !== false
                                  ? "bg-neon-green/20 text-neon-green"
                                  : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              {c.isActive !== false ? "Aktiv" : "Deaktiviert"}
                            </button>
                            <button
                              onClick={async () => {
                                if (!confirm(`Community "${c.name}" wirklich loeschen?`)) return;
                                try { await api.admin.deleteCommunity(c.id); await loadCommunities(); }
                                catch { alert("Fehler."); }
                              }}
                              className="rounded-lg bg-red-500/10 px-3 py-1.5 text-xs text-red-400 hover:bg-red-500/20"
                            >
                              Loeschen
                            </button>
                          </div>
                        </div>

                        {/* Toggle showOnHomepage */}
                        <div className="flex items-center justify-between">
                          <div className="text-sm font-medium text-white">Startseite</div>
                          <button
                            onClick={async () => {
                              try {
                                await api.admin.updateCommunity(c.id, { showOnHomepage: !c.showOnHomepage });
                                await loadCommunities();
                              } catch { alert("Fehler."); }
                            }}
                            className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
                              c.showOnHomepage
                                ? "bg-accent-500/20 text-accent-400"
                                : "bg-surface-700/50 text-surface-400"
                            }`}
                          >
                            {c.showOnHomepage ? "Ô£ô Auf Startseite angezeigt" : "Nicht auf Startseite"}
                          </button>
                        </div>

                        {/* Bilder & Flagge bearbeiten */}
                        <div className="space-y-3">
                          <div className="text-sm font-medium text-white">Bilder &amp; Flagge</div>
                          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                            <div>
                              <Label>Flaggen-Code (ISO)</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  defaultValue={c.flagCode || ""}
                                  placeholder="z.B. tr, gr, rs"
                                  onBlur={async (e: any) => {
                                    const v = e.target.value.trim() || null;
                                    if (v !== (c.flagCode || null)) {
                                      try { await api.admin.updateCommunity(c.id, { flagCode: v }); await loadCommunities(); } catch { alert("Fehler."); }
                                    }
                                  }}
                                />
                                {(c.flagUrl || c.flagCode || c.country) && (
                                  <img src={c.flagUrl || `https://hatscripts.github.io/circle-flags/flags/${(c.flagCode || c.country || "").toLowerCase()}.svg`} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover ring-1 ring-white/10" />
                                )}
                              </div>
                            </div>
                            <div>
                              <Label>Flaggen-Bild URL</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  defaultValue={c.flagUrl || ""}
                                  placeholder="https://... (ueberschreibt ISO-Code)"
                                  onBlur={async (e: any) => {
                                    const v = e.target.value.trim() || null;
                                    if (v !== (c.flagUrl || null)) {
                                      try { await api.admin.updateCommunity(c.id, { flagUrl: v }); await loadCommunities(); } catch { alert("Fehler."); }
                                    }
                                  }}
                                />
                                {c.flagUrl && (
                                  <img src={c.flagUrl} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover ring-1 ring-white/10" />
                                )}
                              </div>
                            </div>
                            <div>
                              <Label>Banner-Bild URL</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  defaultValue={c.bannerUrl || ""}
                                  placeholder="https://images.unsplash.com/..."
                                  onBlur={async (e: any) => {
                                    const v = e.target.value.trim() || null;
                                    if (v !== (c.bannerUrl || null)) {
                                      try { await api.admin.updateCommunity(c.id, { bannerUrl: v }); await loadCommunities(); } catch { alert("Fehler."); }
                                    }
                                  }}
                                />
                                {c.bannerUrl && (
                                  <img src={c.bannerUrl} alt="" className="h-8 w-12 shrink-0 rounded object-cover ring-1 ring-white/10" />
                                )}
                              </div>
                            </div>
                            <div>
                              <Label>Logo URL</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  defaultValue={c.imageUrl || ""}
                                  placeholder="https://..."
                                  onBlur={async (e: any) => {
                                    const v = e.target.value.trim() || null;
                                    if (v !== (c.imageUrl || null)) {
                                      try { await api.admin.updateCommunity(c.id, { imageUrl: v }); await loadCommunities(); } catch { alert("Fehler."); }
                                    }
                                  }}
                                />
                                {c.imageUrl && (
                                  <img src={c.imageUrl} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover ring-1 ring-white/10" />
                                )}
                              </div>
                            </div>
                          </div>
                          <p className="text-[10px] text-surface-600">Aenderungen werden beim Verlassen des Feldes gespeichert. Flaggen-Code und Banner werden auf der Startseite angezeigt.</p>
                        </div>

                        {/* Mitglied hinzufuegen */}
                        <div>
                          <div className="text-sm font-medium text-white mb-2">Mitglied hinzufuegen</div>
                          <p className="text-xs text-surface-500 mb-3">Suche nach einem Benutzer und weise ihm eine Rolle in dieser Community zu.</p>

                          {/* Step 1: User suchen */}
                          <div className="flex gap-2 mb-2">
                            <Input
                              value={userSearch}
                              onChange={(e: any) => setUserSearch(e.target.value)}
                              placeholder="Name oder E-Mail eingeben..."
                              onKeyDown={(e: any) => { if (e.key === "Enter") searchUsers(userSearch); }}
                            />
                            <Button onClick={() => searchUsers(userSearch)} disabled={searching}>
                              {searching ? "..." : "Suchen"}
                            </Button>
                          </div>

                          {/* Search results */}
                          {searchResults.length > 0 && (
                            <div className="mb-3 space-y-1 max-h-48 overflow-y-auto rounded-lg border border-white/[0.06] bg-white/[0.01] p-2">
                              {searchResults.map((u) => (
                                <button
                                  key={u.id}
                                  onClick={() => { setRoleAssign((p: any) => ({ ...p, userId: u.id, userName: u.name + " (" + u.email + ")" })); }}
                                  className={`w-full text-left flex items-center justify-between rounded-lg px-3 py-2 text-xs transition-all ${
                                    roleAssign.userId === u.id
                                      ? "bg-accent-500/15 border border-accent-500/30"
                                      : "hover:bg-white/[0.04] border border-transparent"
                                  }`}
                                >
                                  <div className="flex items-center gap-2">
                                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-accent-500/10 text-[10px] font-bold text-accent-400">
                                      {u.name.charAt(0).toUpperCase()}
                                    </div>
                                    <div>
                                      <span className="font-medium text-white">{u.name}</span>
                                      <span className="ml-2 text-surface-500">{u.email}</span>
                                    </div>
                                  </div>
                                  {roleAssign.userId === u.id && (
                                    <span className="text-[10px] font-bold text-accent-400">AUSGEWAEHLT</span>
                                  )}
                                </button>
                              ))}
                              {searchPages > 1 && (
                                <div className="flex items-center justify-center gap-2 pt-2">
                                  <button disabled={searchPage <= 1} onClick={() => searchUsers(userSearch, searchPage - 1)} className="text-xs text-surface-400 hover:text-white disabled:opacity-30">ÔåÉ Zurueck</button>
                                  <span className="text-xs text-surface-500">{searchPage}/{searchPages} ({searchTotal} Treffer)</span>
                                  <button disabled={searchPage >= searchPages} onClick={() => searchUsers(userSearch, searchPage + 1)} className="text-xs text-surface-400 hover:text-white disabled:opacity-30">Weiter ÔåÆ</button>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Step 2: Ausgewaehlter User + Rolle + Zuweisen */}
                          {roleAssign.userId && (
                            <div className="flex items-center gap-2 rounded-lg border border-accent-500/20 bg-accent-500/5 px-3 py-2">
                              <div className="flex-1 text-xs">
                                <span className="text-surface-500">Ausgewaehlt:</span>{" "}
                                <span className="font-medium text-white">{roleAssign.userName || roleAssign.userId}</span>
                              </div>
                              <select
                                value={roleAssign.role}
                                onChange={(e: any) => setRoleAssign((p: any) => ({ ...p, role: e.target.value }))}
                                className="rounded-lg border border-white/10 bg-white/[0.03] px-2 py-1.5 text-xs text-white focus:border-accent-500 focus:outline-none"
                              >
                                <option value="MEMBER">Mitglied</option>
                                <option value="MODERATOR">Moderator</option>
                                <option value="ADMIN">Admin</option>
                              </select>
                              <Button
                                onClick={async () => {
                                  try {
                                    await api.admin.assignCommunityRole(c.id, roleAssign.userId.trim(), roleAssign.role);
                                    setRoleAssign({ userId: "", userName: "", role: "MEMBER" });
                                    setSearchResults([]);
                                    setUserSearch("");
                                    await loadCommunityMembers(c.id);
                                  } catch (e: any) { alert(e?.message || "Fehler."); }
                                }}
                              >
                                Hinzufuegen
                              </Button>
                              <button
                                onClick={() => setRoleAssign({ userId: "", userName: "", role: "MEMBER" })}
                                className="text-xs text-surface-500 hover:text-white"
                              >
                                Ô£ò
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Members list */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="text-sm font-medium text-white">Mitglieder</div>
                            <Input
                              value={memberSearch}
                              onChange={(e: any) => { setMemberSearch(e.target.value); loadCommunityMembers(c.id, e.target.value); }}
                              placeholder="Mitglied suchen..."
                              className="!w-48"
                            />
                          </div>
                          {communityMembersLoading ? (
                            <div className="text-xs text-surface-500">Lade...</div>
                          ) : communityMembers.length === 0 ? (
                            <div className="text-xs text-surface-500">Keine Mitglieder.</div>
                          ) : (
                            <div className="space-y-1">
                              {communityMembers.map((m) => (
                                <div key={m.id} className="flex items-center justify-between rounded-lg border border-white/[0.06] bg-white/[0.02] px-3 py-2 text-xs">
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium text-white">{m.user.name}</span>
                                    {m.user.email && <span className="text-surface-500">{m.user.email}</span>}
                                    <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${
                                      m.role === "ADMIN" ? "bg-red-500/20 text-red-400" :
                                      m.role === "MODERATOR" ? "bg-amber-500/20 text-amber-400" :
                                      "bg-surface-700/50 text-surface-400"
                                    }`}>{m.role}</span>
                                  </div>
                                  <div className="flex gap-1">
                                    <select
                                      value={m.role}
                                      onChange={async (e: any) => {
                                        try {
                                          await api.communities.updateMemberRole(c.slug, m.id, e.target.value);
                                          await loadCommunityMembers(c.id, memberSearch);
                                        } catch { alert("Fehler."); }
                                      }}
                                      className="rounded bg-white/5 px-2 py-1 text-[10px] text-surface-400 focus:outline-none"
                                    >
                                      <option value="MEMBER">Member</option>
                                      <option value="MODERATOR">Moderator</option>
                                      <option value="ADMIN">Admin</option>
                                    </select>
                                    <button
                                      onClick={async () => {
                                        if (!confirm(`${m.user.name} wirklich entfernen?`)) return;
                                        try {
                                          await api.admin.removeCommunityMember(c.id, m.id);
                                          await loadCommunityMembers(c.id, memberSearch);
                                        } catch { alert("Fehler."); }
                                      }}
                                      className="rounded bg-red-500/10 px-2 py-1 text-[10px] text-red-400 hover:bg-red-500/20"
                                    >
                                      Entfernen
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* ─── Users Tab ─── */}
      {tab === "users" && (<section className="space-y-4 rounded-3xl border border-white/[0.08] bg-surface-900/70 p-5 sm:p-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-surface-400">Alle registrierten Benutzer. Partner-Rechte vergeben und URLs hinterlegen.</p>
        <span className="text-xs text-surface-500">{users.length} Benutzer</span>
      </div>

      {loading ? (
        <div className="py-12 text-center text-sm text-surface-500">Lade Benutzer...</div>
      ) : users.length === 0 ? (
        <div className="py-12 text-center text-sm text-surface-500">Keine Benutzer gefunden.</div>
      ) : (
        <div className="space-y-2">
          {users.map((u) => {
            const isExpanded = expandedUser === u.id;
            return (
              <div key={u.id} className="rounded-2xl border border-white/[0.06] bg-surface-900 overflow-hidden transition-all hover:border-white/[0.10]">
                {/* User Header */}
                <button
                  onClick={() => setExpandedUser(isExpanded ? null : u.id)}
                  className="w-full text-left px-5 py-4 hover:bg-white/[0.02] transition-colors"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent-500/20 text-sm font-bold text-accent-400">
                        {u.name?.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-white">{u.name}</span>
                          {u.isAdmin && (
                            <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-[9px] font-bold uppercase text-red-400">Admin</span>
                          )}
                          {u.isPartner && (
                            <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[9px] font-bold uppercase text-emerald-400">Partner</span>
                          )}
                          {!u.isPartner && !u.isAdmin && (
                            <span className="rounded-full bg-surface-700/50 px-2 py-0.5 text-[9px] font-bold uppercase text-surface-500">Standard</span>
                          )}
                        </div>
                        <div className="mt-0.5 text-xs text-surface-500 truncate">{u.email}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-xs shrink-0">
                      <div className="hidden sm:flex items-center gap-3 text-surface-500">
                        <span><span className="text-surface-600">Events</span> <span className="font-medium text-surface-300">{u._count.events}</span></span>
                        <span><span className="text-surface-600">URLs</span> <span className="font-medium text-surface-300">{u.monitoredUrls.length}</span></span>
                        {u.isPartner && <span className="font-medium text-amber-400">{u.promotionTokens} Tokens</span>}
                      </div>
                      <span className="text-surface-600">{isExpanded ? "▲" : "▼"}</span>
                    </div>
                  </div>
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-white/[0.06] bg-surface-950/40 px-5 py-4 space-y-5">
                    {/* Partner Toggle */}
                    <div className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
                      <div>
                        <div className="text-sm font-medium text-white">Partner-Status</div>
                        <div className="text-xs text-surface-500">Partner können die automatische Indexierung nutzen.</div>
                      </div>
                      <button
                        onClick={() => togglePartner(u.id, u.isPartner)}
                        disabled={busy === u.id}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          u.isPartner ? "bg-neon-green/60" : "bg-surface-700"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            u.isPartner ? "translate-x-6" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>

                    {/* Promotion Tokens */}
                    {u.isPartner && (
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-medium text-white">Promotion Tokens</div>
                          <div className="text-xs text-surface-500">Tokens fuer bevorzugte Listung. 1 Token pro Monat automatisch.</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-bold text-amber-400">{u.promotionTokens}</span>
                          <input
                            type="number"
                            min="0"
                            value={tokenInputs[u.id] ?? String(u.promotionTokens)}
                            onChange={(e: any) => setTokenInputs((prev) => ({ ...prev, [u.id]: e.target.value }))}
                            className="w-16 rounded-lg border border-white/10 bg-white/[0.03] px-2 py-1 text-center text-sm text-white focus:border-accent-500 focus:outline-none"
                          />
                          <button
                            onClick={async () => {
                              const val = parseInt(tokenInputs[u.id] ?? String(u.promotionTokens), 10);
                              if (isNaN(val) || val < 0) return;
                              setBusy(u.id);
                              try {
                                await api.admin.updateUser(u.id, { promotionTokens: val });
                                setTokenInputs((prev) => { const n = { ...prev }; delete n[u.id]; return n; });
                                await loadUsers();
                              } catch { alert("Fehler."); }
                              finally { setBusy(null); }
                            }}
                            disabled={busy === u.id || (tokenInputs[u.id] ?? String(u.promotionTokens)) === String(u.promotionTokens)}
                            className="rounded-lg bg-amber-500/20 px-3 py-1 text-xs font-medium text-amber-400 hover:bg-amber-500/30 disabled:opacity-30"
                          >
                            Setzen
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Website */}
                    {u.website && (
                      <div className="text-xs text-surface-500">
                        Website: <a href={u.website} target="_blank" rel="noreferrer" className="text-accent-400 hover:text-accent-300">{u.website}</a>
                      </div>
                    )}

                    {/* Monitored URLs */}
                    <div>
                      <div className="text-sm font-medium text-white mb-2">Ueberwachte Seiten ({u.monitoredUrls.length})</div>

                      {u.monitoredUrls.length > 0 && (
                        <div className="space-y-1.5 mb-3">
                          {u.monitoredUrls.map((mu) => (
                            <div
                              key={mu.id}
                              className={`flex items-center gap-2 rounded-lg border p-2.5 text-xs ${
                                mu.isActive
                                  ? "border-white/[0.08] bg-white/[0.02]"
                                  : "border-white/[0.04] bg-white/[0.01] opacity-50"
                              }`}
                            >
                              <div className={`h-1.5 w-1.5 rounded-full shrink-0 ${mu.isActive ? (mu.errorCount > 0 ? "bg-amber-400" : "bg-neon-green") : "bg-surface-600"}`} />
                              <div className="flex-1 min-w-0">
                                <div className="text-white truncate">{mu.label || mu.url}</div>
                                {mu.label && <div className="text-surface-600 truncate">{mu.url}</div>}
                                <div className="flex gap-2 text-surface-600 mt-0.5">
                                  {mu.lastScrapedAt && (
                                    <span>Letzter Scan: {new Date(mu.lastScrapedAt).toLocaleDateString("de-DE", { day: "numeric", month: "short" })}</span>
                                  )}
                                  {mu.lastEventCount > 0 && <span className="text-neon-green">{mu.lastEventCount} neue</span>}
                                  {mu.errorCount > 0 && <span className="text-amber-400">Fehler: {mu.lastError}</span>}
                                </div>
                              </div>
                              <div className="flex gap-1 shrink-0">
                                <button
                                  onClick={() => toggleUrlActive(mu.id, mu.isActive)}
                                  className="rounded bg-white/5 px-2 py-1 text-[10px] text-surface-400 hover:bg-white/10"
                                >
                                  {mu.isActive ? "Pause" : "Aktiv"}
                                </button>
                                <button
                                  onClick={() => deleteUrl(mu.id)}
                                  className="rounded bg-red-500/10 px-2 py-1 text-[10px] text-red-400 hover:bg-red-500/20"
                                >
                                  X
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Add URLs */}
                      <div className="space-y-2">
                        <Label>URLs hinzufuegen (eine pro Zeile, optional: URL|Bezeichnung)</Label>
                        <textarea
                          value={newUrls[u.id] || ""}
                          onChange={(e: any) => setNewUrls((prev) => ({ ...prev, [u.id]: e.target.value }))}
                          placeholder={"https://venue.de/events\nhttps://venue.de/konzerte|Konzerte\nhttps://venue.de/theater|Theater"}
                          rows={3}
                          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white placeholder:text-surface-600 focus:border-accent-500 focus:outline-none focus:ring-1 focus:ring-accent-500 font-mono"
                        />
                        <Button
                          onClick={() => addUrls(u.id)}
                          disabled={busy === u.id || !(newUrls[u.id] || "").trim()}
                        >
                          {busy === u.id ? "Speichere..." : "URLs hinzufuegen"}
                        </Button>
                      </div>
                    </div>

                    {/* Info */}
                    <div className="text-[10px] text-surface-600">
                      Registriert: {new Date(u.createdAt).toLocaleDateString("de-DE", { day: "numeric", month: "long", year: "numeric" })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>)}
    </div>
  );
}
