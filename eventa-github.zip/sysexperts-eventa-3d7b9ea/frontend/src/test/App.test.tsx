import { describe, expect, it } from "vitest";

describe("App", () => {
  it("placeholder", () => {
    expect(true).toBe(true);
  });
});
