module.exports = {
  semi: true,
  singleQuote: false,
  trailingComma: "es5"
};
