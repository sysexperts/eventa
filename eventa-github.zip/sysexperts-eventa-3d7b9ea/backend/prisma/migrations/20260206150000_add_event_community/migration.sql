-- AlterTable
ALTER TABLE "Event" ADD COLUMN "community" TEXT;
