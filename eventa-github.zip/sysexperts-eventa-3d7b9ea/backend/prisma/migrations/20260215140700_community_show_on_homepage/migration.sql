-- AlterTable
ALTER TABLE "Community" ADD COLUMN "showOnHomepage" BOOLEAN NOT NULL DEFAULT false;
