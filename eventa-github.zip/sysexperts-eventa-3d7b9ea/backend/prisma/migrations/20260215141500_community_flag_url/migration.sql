-- AlterTable
ALTER TABLE "Community" ADD COLUMN "flagUrl" TEXT;
