-- AlterTable
ALTER TABLE "User" ADD COLUMN "address" TEXT,
ADD COLUMN "zip" TEXT,
ADD COLUMN "city" TEXT,
ADD COLUMN "phone" TEXT,
ADD COLUMN "companyName" TEXT;
