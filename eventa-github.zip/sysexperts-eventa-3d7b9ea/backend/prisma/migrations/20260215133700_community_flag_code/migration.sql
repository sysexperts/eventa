-- AlterTable
ALTER TABLE "Community" ADD COLUMN "flagCode" TEXT;
