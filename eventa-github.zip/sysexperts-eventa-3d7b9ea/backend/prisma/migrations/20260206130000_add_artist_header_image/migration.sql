-- AlterTable
ALTER TABLE "Artist" ADD COLUMN "headerImageUrl" TEXT;
